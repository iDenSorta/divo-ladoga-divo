function b(){

let divadd = document.getElementById('divadd')


let div2 = divadd.cloneNode(true);


divadd.after(div2);
}

let a = document.getElementById('addlink');

a.onclick = b;

