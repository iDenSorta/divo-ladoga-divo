// core version + navigation, pagination modules:
import Swiper, { Navigation, Pagination } from 'swiper';
// import Swiper and modules styles
import 'swiper/less';
import 'swiper/less/navigation';
import 'swiper/less/pagination';



const swiper_popup = new Swiper('.swiper-popup', {
 modules: [Navigation, Pagination],



 
 pagination: {
   el: '.swiper-pagination#popup',
 },

 // If we need pagination
 navigation: {
     nextEl: ".swiper-button-next#popup",
     prevEl: ".swiper-button-prev#popup",
   },
 
 
 
  
}

)

 




const swiper_catalog = new Swiper('.swiper-feedback', {
 modules: [Navigation],

 spaceBetween: 16,
 breakpointsBase: 'window',
 
 // If we need pagination
 navigation: {
     nextEl: ".swiper-button-next#feedback",
     prevEl: ".swiper-button-prev#feedback",
   },
 
 breakpoints: {
   100:{
     slidesPerView: 1,
     
   },

   430:{
     slidesPerView: 1,
     spaceBetween: 6,

   },
   
   430:{
     slidesPerView: 1,
     
   },

   1024: {
     
     slidesPerView: 2,
     spaceBetween: 16,
     
   },

   1280: {
     
     slidesPerView: 2.5,
     spaceBetween: 16,
     
   },

   
   
   1440: {
     slidesPerView: 2.5,
     spaceBetween: 16,
   },
   
 
   },
}

)

 

   
   
