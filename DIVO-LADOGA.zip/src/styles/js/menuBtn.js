let menuBtn = document.querySelector('.menu__btn');
let menuWrapper = document.querySelector('.menu-nav');

menuBtn.addEventListener('click',function(){
  menuBtn.classList.toggle('active');
  menuWrapper.classList.toggle('active');

} )

