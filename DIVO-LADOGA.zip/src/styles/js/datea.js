const dayjs = require('dayjs')
//import dayjs from 'dayjs' // ES 2015
dayjs().format()


var dateControl = document.querySelectorAll('input[type="date"]');

for (var i=0; i<dateControl.length; i++){
    
    dateControl[i].value = dayjs().format('YYYY-MM-DD')
    dateControl[i].min = dayjs().format('YYYY-MM-DD')
    
}

