import "./styles/style.less"
import "../src/styles/js/menuBtn.js"
import "./styles/js/switch"
import "./styles/js/datea"
import "./styles/js/add.js"

import "./styles/js/swiper.js"


 